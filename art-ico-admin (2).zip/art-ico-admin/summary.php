<?php include('header.php');?>

  <div class="heading-row mb-20">
    <div class="row align-item-center">
       <div class="col-lg-6">
          <h3 class="page-title"><span class="page-title-icon bg-gradient-primary text-white mr-2"><i class="mdi mdi-file-image"></i></span> Art Cash Details </h3>
       </div>
  </div>
  </div>
  <div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
      <div class="card">
         <div class="card-header">
           <div class="row">
            <div class="col-md-2">
                  <div class="form-group">
                    <select id="select-new" class="form-control">
                        <option>Name</option>
                        <option>Willian Smith</option>
                        <option>Dia Firdaus</option>
                        <option>Zimmy Wu</option>
                      </select>
                  </div>
            </div> 
            <div class="col-md-2">
                  <div class="form-group">
                    <select id="select-new2" class="form-control">
                        <option>Periculer</option>
                        <option>Per Painting Upload</option>
                        <option>Refer to Other</option>
                        <option>Joining Bonus</option>
                      </select>
                  </div>
            </div>  
            <div class="col-md-2">
                  <div class="form-group">
                    <select id="select-new3" class="form-control">
                        <option>ARTW Balance</option>
                        <option>0-50</option>
                        <option>50-100</option>
                        <option>100-150</option>
                      </select>
                  </div>
            </div> 
                        
         </div>
         </div> 
        <div class="card-body table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th width="5%">S. No.</th>
                <th width="10%">User ID</th>
                <th width="10%">Name</th>
                <th width="10%">Email</th>
                <th width="10%">Wallet</th>
                <th width="10%">Particulers</th>
                <th width="10%" class="text-success">Earned</th>
                <th width="8%" class="text-danger">Spent</th>
                <th width="8%">Balance in ARTW</th>
                <th width="8%">Balance in USD</th>
                <th width="10%">View</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>1</td>
                <td>112</td>
                <td>Nawaj Shekh</td>
                <td>abc@gmail.com</td>
                <td>50</td>
                <td>Joining Bonus</td>
                
                <td class="text-success">+77.99</td>
                 <td class="text-danger">+77.99</td>
                 <td>50 ARTW</td>
                 <td>$ 115.00</td>
                 <td>
                    <div class="edit-icons">
                    <a href="art-list-details.php"><i class="mdi mdi-eye"></i></a>
                  </div>
                 </td>
              </tr>
              <tr>
                <td>2</td>
                <td>112</td>
                <td>Nawaj Shekh</td>
                <td>abc@gmail.com</td>
                <td>50</td>
                <td>Referral Bonus</td>
                
                <td class="text-success">+77.99</td>
                 <td class="text-danger">+77.99</td>
                 <td>50 ARTW</td>
                 <td>$ 115.00</td>
                 <td>
                    <div class="edit-icons">
                    <a href="art-list-details.php"><i class="mdi mdi-eye"></i></a>
                  </div>
                 </td>
              </tr>
              <tr>
                <td>3</td>
                <td>112</td>
                <td>Nawaj Shekh</td>
                <td>abc@gmail.com</td>
                <td>50</td>
                <td>Special Bonus</td>
                
                <td class="text-success">+77.99</td>
                 <td class="text-danger">+77.99</td>
                 <td>50 ARTW</td>
                 <td>$ 115.00</td>
                 <td>
                    <div class="edit-icons">
                    <a href="art-list-details.php"><i class="mdi mdi-eye"></i></a>
                  </div>
                 </td>
              </tr>
               
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

<?php include('footer.php');?>


  <script>
$(document).ready( function () {
  $('.table').DataTable();
} );
</script>